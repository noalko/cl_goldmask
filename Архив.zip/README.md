# Binomo Cloaker
Модифицированный скрипт клоакинга, изначально найденный на просторах Black Hat Forum.

Настройка тут: https://vk.com/@webyellow-kloaking-dlya-bednogo-no-umnogo-arbitrazhnika

По всем вопросам пишите Issues на GitHub либо в паблик http://vk.com/webyellow

Если вы налили кучу лидов с помощью этой штуки и *хотите сделать доброе дело* - **зайдите в паблик и киньте донат**!
